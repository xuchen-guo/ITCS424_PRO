package edu.cn.studentadminister.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.cn.bookadminister.R;
import edu.cn.studentadminister.bean.Student;
import edu.cn.studentadminister.bean.StudentsDAO;

public class AddActivity extends AppCompatActivity implements View.OnClickListener {
    //the identification of the module
    private EditText etStudentid;
    private EditText etStudentname;
    private EditText etMajoy;
    private EditText etStudentclass;

    private Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addbooks);
        //the initial Ui
        initView();
    }

    //the initial Ui
    private void initView() {
        etStudentid=(EditText)findViewById(R.id.et_studentid);
        etStudentname = (EditText) findViewById(R.id.et_studentname);
        etMajoy = (EditText) findViewById(R.id.et_majoy);
        etStudentclass = (EditText) findViewById(R.id.et_studentclass);

        btnAdd = (Button) findViewById(R.id.btn_add);
        //setting the button & clickable
        btnAdd.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        //when clicking the add button, add the new variable
        String studentid=etStudentid.getText().toString().trim();
        String studentname = etStudentname.getText().toString().trim();
        String majoy = etMajoy.getText().toString().trim();
        String studentclass = etStudentclass.getText().toString();


        //to check the information
        if (TextUtils.isEmpty(studentid)) {
            Toast.makeText(this, "Please enter the students Id", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(studentname)) {
            Toast.makeText(this, "Please type your name", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(majoy)) {
            Toast.makeText(this, "Please type your major", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(studentclass)) {
            Toast.makeText(this, "Please type your class", Toast.LENGTH_SHORT).show();
            return;
        }

        //add the students information
        Student o =new Student();
        o.studentid= studentid;
        o.studentname = studentname;
        o.majoy = majoy;
        o.studentclass = studentclass;

        //to creat the database
        StudentsDAO dao = new StudentsDAO(getApplicationContext());
        //open the database
        dao.open();
        //to excute the method of database
        long result = dao.addStudents(o);

        if (result > 0) {
            Toast.makeText(this, "Sucessfully Added", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed Added", Toast.LENGTH_SHORT).show();
        }
        //close the database
        dao.close();
        //finish the activity
        finish();
    }
}