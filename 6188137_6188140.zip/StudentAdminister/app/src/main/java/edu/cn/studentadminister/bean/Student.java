package edu.cn.studentadminister.bean;

public class Student {
    public String studentid;
    public String studentname;
    public String majoy;
    public String studentclass;
}