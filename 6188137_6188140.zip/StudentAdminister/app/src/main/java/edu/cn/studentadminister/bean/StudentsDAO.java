package edu.cn.studentadminister.bean;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import edu.cn.studentadminister.bean.Student;
import edu.cn.studentadminister.database.MyDBHelper;

public class StudentsDAO {
    private Context context;
    private MyDBHelper dbHelper;
    private SQLiteDatabase db;

    //to build the functioin
    public StudentsDAO(Context context) {
        this.context = context;
    }

    //open the database
    public void open() throws SQLiteException {
        dbHelper = new MyDBHelper(context);
        try {
            db = dbHelper.getWritableDatabase();
        } catch (SQLiteException ex) {
            db = dbHelper.getReadableDatabase();
        }
    }

    //close the database
    public void close() {
        if (db != null) {
            db.close();
            db = null;
        }
    }


    //add the students information
    public long addStudents(Student o) {
        // build the ContentValues
        ContentValues values = new ContentValues();
        // put the key to the object
        values.put("studentid", o.studentid);
        values.put("studentname", o.studentname);
        values.put("majoy", o.majoy);
        values.put("studentclass", o.studentclass);

        // Call the insert() method to insert data into the database
        return db.insert("tb_Students", null, values);
    }

    //delete the infor
    public int deletStudents(Student o) {
        return db.delete("tb_Students", "studentid=?", new String[]{String.valueOf(o.studentid)});
    }

    //to modify the infor
    public int updateStudents(Student o) {
        ContentValues value = new ContentValues();
        value.put("studentname", o.studentname);
        value.put("majoy", o.majoy);
        value.put("studentclass", o.studentclass);
        return db.update("tb_Students", value, "studentid=?", new String[]{String.valueOf(o.studentid)});
    }

    //find the student by the ID
    @SuppressLint("Range")
    public Student getStudents(String studentid) {
        //the search the student
        Cursor cursor = db.query("tb_Students", null, "studentid=?", new String[]{studentid}, null, null, null);
        Student o = new Student();
        while (cursor.moveToNext()) {
            o.studentid = cursor.getString(cursor.getColumnIndex("studentid"));
            o.studentname = cursor.getString(cursor.getColumnIndex("studentname"));
            o.majoy = cursor.getString(cursor.getColumnIndex("majoy"));
            o.studentclass = cursor.getString(cursor.getColumnIndex("studentclass"));

        }
        return o;
    }

    //the check all the inormation
    @SuppressLint("Range")
    public ArrayList<Map<String, Object>> getAllstudents() {
        ArrayList<Map<String, Object>> listStudents = new ArrayList<Map<String, Object>>();
        Cursor cursor = db.query("tb_Students", null, null, null, null, null,null);

        int resultCounts = cursor.getCount();  //the record the data
        if (resultCounts == 0 ) {
            return null;
        } else {
            while (cursor.moveToNext()) {
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("studentid", cursor.getString(cursor.getColumnIndex("studentid")));
                map.put("studentname", cursor.getString(cursor.getColumnIndex("studentname")));
                map.put("majoy", cursor.getString(cursor.getColumnIndex("majoy")));
                map.put("studentclass", cursor.getString(cursor.getColumnIndex("studentclass")));
                listStudents.add(map);
            }
            return listStudents;
        }
    }
}