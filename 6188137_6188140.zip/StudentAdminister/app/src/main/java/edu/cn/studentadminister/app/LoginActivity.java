package edu.cn.studentadminister.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import edu.cn.studentadminister.database.MD5Utils;
import edu.cn.bookadminister.R;

public class  LoginActivity extends AppCompatActivity {
    private Button login;
    private TextView tv_register;
    private EditText et_username,et_pwd;
    private CheckBox save_pwd;
    private String userName,passWord,spPsw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
    }
    private void init() {
        et_username = (EditText) findViewById(R.id.loginusername);
        et_pwd = (EditText) findViewById(R.id.loginpwd);
        save_pwd = (CheckBox) findViewById(R.id.save_pwd);
        login = (Button)findViewById(R.id.loginBtn);
        tv_register = (TextView) findViewById(R.id.register);
        //to gain the remembered id number and account unmber
        getUserInfo();
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //begin log in
                getEditString();
                //Perform MD5 encryption on the password entered by the current user and then compare and judge, MD5Utils.md5( ); psw performs encryption to judge whether it is consistent
                String md5Psw= MD5Utils.md5(passWord);
                // md5Psw ; spPsw reads the password based on the username from SharedPreferences
                // Define the method readPsw in order to read the username and get the password
                spPsw = readPsw(userName);
                // TextUtils.isEmpty
                if(TextUtils.isEmpty(userName)){
                    Toast.makeText( LoginActivity.this, "Please enter user name", Toast.LENGTH_SHORT).show();
                    return;
                }else if(TextUtils.isEmpty(passWord)){
                    Toast.makeText( LoginActivity.this, "Please enter the password", Toast.LENGTH_SHORT).show();
                    return;
                    // md5Psw.equals(); Determine whether the entered password is the same as that stored in SharedPreferences after encryption
                }else if(md5Psw.equals(spPsw)){
                    //successfuly log in
                    Toast.makeText( LoginActivity.this, "welcome！"+ userName, Toast.LENGTH_SHORT).show();
                    //Save the login status and save the logged in user name in the interface Define a method saveLoginStatus boolean status, userName username
                    saveLoginInfo(userName,passWord);
                    //getUserInfo();
                    saveLoginStatus(true, userName);
                   //Close this page and enter the homepage after successful login
                    Intent data = new Intent();
                    //data.putExtra( ); name , value ;
                    data.putExtra("isLogin",true);
                    //RESULT_OK is the Activity system constant, and the status code is -1
                    // Indicates that the content operation under this page successfully returns the data to the previous page. If it is returned to the past with back, there is no data value passed with setResult.
                    setResult(RESULT_OK,data);
                    //to destory the log in page
                    LoginActivity.this.finish();
                    //Jump to the main interface, the status of successful login is passed to MainActivity
                    startActivity(new Intent( LoginActivity.this, MainActivity.class));
                    return;
                }else if((spPsw!=null&&!TextUtils.isEmpty(spPsw)&&!md5Psw.equals(spPsw))){
                    Toast.makeText( LoginActivity.this, "the wrong password", Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    Toast.makeText( LoginActivity.this, "the user does not exist", Toast.LENGTH_SHORT).show();
                }
            }
        });
        tv_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               //In order to jump to the registration interface and implement the registration function
                Intent intent=new Intent( LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                LoginActivity.this.finish();
            }
        });

    }
    private void getEditString(){
        userName = et_username.getText().toString().trim();
        passWord = et_pwd.getText().toString().trim();
    }
    public void saveLoginInfo(String userName, String passWord){
        //获取SharedPreferences target
        boolean CheckBoxLogin = save_pwd.isChecked();
        SharedPreferences sp = getSharedPreferences("userInfo", MODE_PRIVATE);
        //get the editor objective
        SharedPreferences.Editor editor = sp.edit();
        if (CheckBoxLogin){
            //to setting the references
            editor.putString("username", userName);
            editor.putString("password", passWord);
            editor.putBoolean("checkboxBoolean",true);
            //submit
            editor.commit();
        }else {
            editor.putString("username", null);
            editor.putString("password", null);
            editor.putBoolean("checkboxBoolean", false);
            editor.commit();
        }
    }

    private String readPsw(String userName){
        //getSharedPreferences("loginInfo",MODE_PRIVATE);
        //"loginInfo",mode_private; MODE_PRIVATE show it can overwirte
        SharedPreferences sp  = getSharedPreferences("loginInfo", MODE_PRIVATE);
        //sp.getString() userName, "";
        return sp.getString(userName , "");
    }
    /**
     *to save the log in status in to SharedPreferences
     */
    private void saveLoginStatus(boolean status,String userName){
        //saveLoginStatus(true, userName);
        //loginInfo show the name of  SharedPreferences sp=getSharedPreferences("loginInfo", MODE_PRIVATE);
        SharedPreferences sp = getSharedPreferences("loginInfo", MODE_PRIVATE);
        //to get the editor
        SharedPreferences.Editor editor = sp.edit();
        //save the login status of type boolean
        editor.putBoolean("isLogin", status);
        //to save the log in user name
        editor.putString("loginUserName", userName);
        //submit the modify
        editor.commit();
    }
    /**
     * successfully register information back to here
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    //sjow the data， onActivityResult
    //startActivityForResult(intent, 1); form the register page get the data
    //int requestCode , int resultCode , Intent data
    // LoginActivity -> startActivityForResult -> onActivityResult();
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
        if(data!=null){
            //get the user name from the register page
            // getExtra().getString("***");
            String userName=data.getStringExtra("userName");
            if(!TextUtils.isEmpty(userName)){
                //to set the user name to et_user_name
                et_username.setText(userName);
                //The setSelection() method of the et_user_name control to set the cursor position
                et_username.setSelection(userName.length());
            }
        }
    }
    public  void getUserInfo(){
        SharedPreferences sp = null;
        sp = this.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        if (sp.getBoolean("checkboxBoolean", false))
        {
            et_username.setText(sp.getString("username", null));
            et_pwd.setText(sp.getString("password", null));
            save_pwd.setChecked(true);
        }else{
            et_username.setText(sp.getString("username", userName));
            et_pwd.setText(sp.getString("password", passWord));
            save_pwd.setChecked(false);
        }
    }
    public void onBackPressed() {
        LoginActivity.this.finish();
    }
}
