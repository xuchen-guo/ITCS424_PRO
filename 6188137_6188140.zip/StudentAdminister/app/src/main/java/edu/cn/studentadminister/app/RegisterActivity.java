package edu.cn.studentadminister.app;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.cn.studentadminister.database.MD5Utils;
import edu.cn.bookadminister.R;


public class RegisterActivity extends AppCompatActivity {
    //to define the variables
    private EditText et_username,et_pwd,et_pwd_sure;
    private Button register;
    private String userName,passWord,passWord_sure;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();
    }
    //the initial
    public void init(){
        //to gain the segment
        et_username = (EditText)findViewById(R.id.username);
        et_pwd = (EditText)findViewById(R.id.pwd);
        et_pwd_sure = (EditText)findViewById(R.id.pwd2);
        register = (Button)findViewById(R.id.registerBtn);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getEditString();
                if(TextUtils.isEmpty(userName)){
                    Toast.makeText(RegisterActivity.this, "Please enter the User name", Toast.LENGTH_SHORT).show();
                    return;
                }else if(TextUtils.isEmpty(passWord)){
                    Toast.makeText(RegisterActivity.this, "Please enter your password", Toast.LENGTH_SHORT).show();
                    return;
                }else if(TextUtils.isEmpty(passWord_sure)){
                    Toast.makeText(RegisterActivity.this, "Please enter your password again", Toast.LENGTH_SHORT).show();
                    return;
                }else if(!passWord.equals(passWord_sure)){
                    Toast.makeText(RegisterActivity.this, "The input of your password is diiferent", Toast.LENGTH_SHORT).show();
                    return;
                    /**
                     *Read the entered username from SharedPreferences and determine whether the username exists in SharedPreferences
                     */
                }else if(isExistUserName(userName)){
                    Toast.makeText(RegisterActivity.this, "the user account has been registered", Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    Toast.makeText(RegisterActivity.this, "Successfully Registered ", Toast.LENGTH_SHORT).show();
                    //Save the account number, password and account ID to the sp
                    /**
                     * Save account and password to SharedPreferences
                     */
                    saveRegisterInfo(userName, passWord);
                    //Pass the account to LoginActivity.java after successful registration (MainActivity.java)
                    // return value to loginActivity display
                    Intent data = new Intent();
                    data.putExtra("userName", userName);
                    setResult(RESULT_OK, data);
                    //RESULT_OK is the Activity system constant, the status code is -1,
                    // Indicates that the content operation under this page successfully returns the data to the previous page. If it is returned to the past with back, there is no data value passed with setResult.
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                    RegisterActivity.this.finish();
                }
            }
        });
    }
    private void getEditString(){
        userName = et_username.getText().toString().trim();
        passWord = et_pwd.getText().toString().trim();
        passWord_sure = et_pwd_sure.getText().toString().trim();
    }
    /**
     * Read the entered user name from SharedPreferences to determine whether there is this user name in SharedPreferences
     */
    private boolean isExistUserName(String userName){
        boolean has_userName = false;
        //mode_private SharedPreferences sp = getSharedPreferences( );
        // "loginInfo", MODE_PRIVATE
        SharedPreferences sp = getSharedPreferences("loginInfo", MODE_PRIVATE);
        //gain the password
        String spPsw = sp.getString(userName, "");//to gain the password from the username
       //If the password is not empty, the username is indeed saved
        if(!TextUtils.isEmpty(spPsw)) {
            has_userName=true;
        }
        return has_userName;
    }
    /**
     * Save account and password to SharedPreferences
     */
    private void saveRegisterInfo(String userName,String psw){
        String md5Psw = MD5Utils.md5(psw);//the secur the password with MD5
        //loginInfo show the folder name, mode_private SharedPreferences sp = getSharedPreferences( );
        SharedPreferences sp = getSharedPreferences("loginInfo", MODE_PRIVATE);
        //to gain the editor， SharedPreferences.Editor  editor -> sp.edit();
        SharedPreferences.Editor editor = sp.edit();
        //Save the username as key and password as value in SharedPreferences
        //key, value, such as key-value pair, editor.putString (username, password);
        editor.putString(userName, md5Psw);
        //submit modify editor.commit();
        editor.commit();
    }
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.setClass(RegisterActivity.this,LoginActivity.class);
        startActivity(intent);
        //to close the activity
        RegisterActivity.this.finish();
    }
}