package edu.cn.studentadminister.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import java.util.List;
import java.util.Map;

import edu.cn.bookadminister.R;
import edu.cn.studentadminister.bean.StudentsDAO;

public class QueryActivity extends AppCompatActivity {
    //to identify the segment
    ListView listView=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query_books);
        setTitle("To check the record");
        //the initial Ui
        initView();
    }

    private void initView() {
        //to build the database target
        StudentsDAO dao=new StudentsDAO(getApplicationContext());
        //open the database
        dao.open();
        //to check the database method
        List<Map<String,Object>> mOrderData=dao.getAllstudents();
        //gain the segment
        listView=(ListView)findViewById(R.id.list_students);
        //to define the dataset
        String[] from={"studentid","studentname","majoy","studentclass"};
        //to identify the ID of setting
        int[] to={R.id.tv_lst_studentid,R.id.tv_lst_studentname,R.id.tv_lst_majoy,R.id.tv_lst_studentclass};
        SimpleAdapter listItemAdapter=new SimpleAdapter(QueryActivity.this,mOrderData,R.layout.item_list,from,to);
        //add and show it
        listView.setAdapter(listItemAdapter);
        //close the database
        dao.close();
    }
}
