package edu.cn.studentadminister.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHelper extends SQLiteOpenHelper {
    //Define database name and version number
    public static final String name = "db_student.db";
    public static final int DB_VERSION = 1;
    //build the database sentence
    public static final String CREATE_USERDATA = "create table tb_Students(studentid char(20)primary key,studentname varchar(20),majoy varchar(20),studentclass varchar(20))";
    //build function
    public MyDBHelper(Context context) {
        super(context, name, null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERDATA);
        db.execSQL("insert into tb_Students(studentid,studentname,majoy,studentclass)Values('6188137','XuChen_Guo','CS','Sec2')");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}