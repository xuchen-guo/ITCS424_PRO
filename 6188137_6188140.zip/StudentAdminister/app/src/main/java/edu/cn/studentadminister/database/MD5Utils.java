package edu.cn.studentadminister.database;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Utils {
    //md5 Encryption Algorithm
    public static String md5(String text) {
        MessageDigest digest = null;
        try {
            digest = MessageDigest.getInstance("md5");
            // the dataset byte[] result -> digest.digest( );   text.getBytes();
            byte[] result = digest.digest(text.getBytes());
            //build StringBuilder target and the StringBuffer，the high security
            //StringBuilder sb = new StringBuilder();
            StringBuffer sb = new StringBuffer();
            // result dataset，digest.digest ( ); -> text.getBytes();
            // for the recycling dataset byte[] result;
            for (byte b : result){
                // 0xff hexadecimal
                int number = b & 0xff;
                // number value conversion string Integer.toHexString( );
                String hex = Integer.toHexString(number);
                if (hex.length() == 1){
                    sb.append("0"+hex);
                }else {
                    sb.append(hex);
                }
            }
            //sb StringBuffer sb = new StringBuffer();to make the target physically
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            //send exception return empty string
            return "";
        }
    }
}