package edu.cn.studentadminister.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import edu.cn.bookadminister.R;
import edu.cn.studentadminister.bean.Student;
import edu.cn.studentadminister.bean.StudentsDAO;

public class UpdateActivity extends AppCompatActivity implements View.OnClickListener{
    //the definition
    private EditText etStudentid;
    private Button btnSearch;
    private EditText etStudentname;
    private EditText etMajoy;
    private EditText etStudentclass;

    private Button btnEdit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_books);
        initView();
    }

    private void initView() {
        etStudentid=(EditText) findViewById(R.id.et_studentid);
        etStudentname=(EditText)findViewById(R.id.et_studentname);
        etMajoy=(EditText)findViewById(R.id.et_majoy);
        etStudentclass=(EditText)findViewById(R.id.et_studentclass);

        btnSearch=(Button) findViewById(R.id.btn_search);
        btnEdit= (Button) findViewById(R.id.btn_edit);
        //setting the button clickable
        btnSearch.setOnClickListener((View.OnClickListener) this);
        btnEdit.setOnClickListener((View.OnClickListener) this);
    }
    @Override
    public void onClick(View v)
    {
        switch(v.getId())
        {
            case R.id.btn_search:   //the search function
                searchOrder();
                break;
            case R.id.btn_edit:    //the update function
                updateOrder();
                break;
        }
    }
    //the search function
    private void searchOrder() {
        //get the user input
        String studentid=etStudentid.getText().toString().trim();
        //build the database visit object
        StudentsDAO dao=new StudentsDAO(getApplicationContext());
        //open the database
        dao.open();
        //to excute the method of visting database
        Student o=dao.getStudents(studentid);
        //put the data into database
        etStudentname.setText(o.studentname);
        etMajoy.setText(o.majoy);
        etStudentclass.setText(o.studentclass);

        //close the database
        dao.close();
    }
    //modify function
    private void updateOrder() {
        Student o=new Student();
        o.studentid=etStudentid.getText().toString().trim();
        o.studentname=etStudentname.getText().toString().trim();
        o.majoy=etMajoy.getText().toString().trim();
        o.studentclass=etStudentclass.getText().toString().trim();

        //to build the database visit target
        StudentsDAO dao=new StudentsDAO(getApplicationContext());
        //open database
        dao.open();
        //to excute the database visite function
        long result= dao.updateStudents(o);
        if(result>0) {
            Toast.makeText(this, "successfully added", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "failed added", Toast.LENGTH_SHORT).show();
        }
        //close the database
        dao.close();
    }
}
