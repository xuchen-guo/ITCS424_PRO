package edu.cn.bookadminister;

public @interface Test {
}
